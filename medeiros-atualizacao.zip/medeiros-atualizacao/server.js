'use strict';

const express = require('express');
const { Client, LocalAuth } = require('whatsapp-web.js');
const QRCode = require('qrcode');
const cron = require('node-cron');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json({ limit: '200kb' }));
app.disable('x-powered-by');

const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const TZ = process.env.TZ || 'America/Sao_Paulo';
const MAX_MESSAGES_PER_DAY = Math.max(1, Number(process.env.MAX_MESSAGES_PER_DAY || 10));
const DATA_DIR = process.env.DATA_DIR || __dirname;
const DATA_FILE = path.join(DATA_DIR, 'data.json');
const AUTH_DIR = path.join(DATA_DIR, '.wwebjs_auth');
const CHROMIUM_PATH = process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium';

if (!ADMIN_PASSWORD) console.error('ERRO: configure ADMIN_PASSWORD nas variáveis do serviço.');
fs.mkdirSync(DATA_DIR, { recursive: true });

let data = { schedules: [], sent: {}, enabled: false };
try {
  if (fs.existsSync(DATA_FILE)) {
    const loaded = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    data = {
      schedules: Array.isArray(loaded.schedules) ? loaded.schedules : [],
      sent: loaded.sent && typeof loaded.sent === 'object' ? loaded.sent : {},
      enabled: loaded.enabled === true
    };
  }
} catch (error) {
  console.error('Não foi possível ler data.json:', error.message);
}

function saveData() {
  const temp = DATA_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(data, null, 2));
  fs.renameSync(temp, DATA_FILE);
}

let client;
let clientState = 'starting';
let latestQR = null;
let lastError = null;
let initInProgress = false;
let tickBusy = false;

function auth(req, res, next) {
  if (!ADMIN_PASSWORD) return res.status(503).json({ error: 'ADMIN_PASSWORD não configurada no servidor.' });
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (token !== ADMIN_PASSWORD) return res.status(401).json({ error: 'Senha incorreta.' });
  next();
}

function todayKey() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
}
function localTimeParts() {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: TZ, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
  }).formatToParts(new Date());
  const get = type => parts.find(p => p.type === type)?.value;
  const weekdayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return { day: weekdayMap[get('weekday')], time: `${get('hour')}:${get('minute')}` };
}

app.get('/health', (_req, res) => {
  res.json({ ok: true, whatsapp: clientState, lastError, note: 'Saúde do servidor; não garante que o WhatsApp esteja conectado.' });
});

app.get('/', (_req, res) => res.type('html').send(PANEL_HTML));
app.use('/api', auth);

app.get('/api/status', (_req, res) => {
  const today = todayKey();
  const sentToday = Number(data.sent[today] || 0);
  res.json({ state: clientState, enabled: data.enabled, schedules: data.schedules, sentToday, maxPerDay: MAX_MESSAGES_PER_DAY, lastError });
});

app.post('/api/connect', async (_req, res) => {
  try {
    if (clientState === 'ready') return res.json({ state: clientState, message: 'WhatsApp já conectado.' });
    if (initInProgress) return res.json({ state: clientState, message: 'Conexão já está sendo iniciada.' });
    initInProgress = true;
    lastError = null;
    clientState = 'starting';
    latestQR = null;
    initClient();
    res.json({ state: clientState, message: 'Inicialização solicitada. Aguarde o QR Code.' });
  } catch (error) {
    initInProgress = false;
    lastError = error.message;
    clientState = 'error';
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/qr', async (_req, res) => {
  if (!latestQR) return res.json({ qr: null, state: clientState, lastError });
  try {
    const qr = await QRCode.toDataURL(latestQR, { margin: 1, width: 320 });
    res.json({ qr, state: clientState });
  } catch (error) {
    res.status(500).json({ error: 'Falha ao gerar QR Code: ' + error.message });
  }
});

app.get('/api/groups', async (_req, res) => {
  if (clientState !== 'ready' || !client) return res.status(409).json({ error: 'Conecte o WhatsApp primeiro.' });
  try {
    const chats = await client.getChats();
    const groups = chats.filter(chat => chat.isGroup).map(chat => ({ id: chat.id._serialized, name: chat.name || 'Grupo sem nome' }));
    res.json({ groups });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/schedules', (req, res) => {
  const { message, groupIds, time, days, active = true } = req.body || {};
  if (typeof message !== 'string' || !message.trim()) return res.status(400).json({ error: 'Informe a mensagem.' });
  if (message.length > 4000) return res.status(400).json({ error: 'Mensagem muito longa (máximo 4.000 caracteres).' });
  if (!Array.isArray(groupIds) || groupIds.length < 1 || groupIds.some(id => typeof id !== 'string' || !/^\d+-\d+@g\.us$/.test(id))) return res.status(400).json({ error: 'Selecione pelo menos um grupo válido.' });
  if (typeof time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return res.status(400).json({ error: 'Horário inválido.' });
  if (!Array.isArray(days) || days.length < 1 || days.some(day => !Number.isInteger(day) || day < 0 || day > 6)) return res.status(400).json({ error: 'Selecione pelo menos um dia.' });
  const schedule = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, message: message.trim(), groupIds: [...new Set(groupIds)], time, days: [...new Set(days)], active: active !== false, createdAt: new Date().toISOString() };
  data.schedules.push(schedule);
  saveData();
  res.json({ ok: true, schedule });
});

app.delete('/api/schedules/:id', (req, res) => {
  const before = data.schedules.length;
  data.schedules = data.schedules.filter(item => item.id !== req.params.id);
  if (before === data.schedules.length) return res.status(404).json({ error: 'Agendamento não encontrado.' });
  saveData();
  res.json({ ok: true });
});

app.patch('/api/schedules/:id', (req, res) => {
  const schedule = data.schedules.find(item => item.id === req.params.id);
  if (!schedule) return res.status(404).json({ error: 'Agendamento não encontrado.' });
  if (typeof req.body.active !== 'boolean') return res.status(400).json({ error: 'Informe active como true ou false.' });
  schedule.active = req.body.active;
  saveData();
  res.json({ ok: true, schedule });
});

app.post('/api/enabled', (req, res) => {
  const enabled = req.body && req.body.enabled;
  if (typeof enabled !== 'boolean') return res.status(400).json({ error: 'Informe enabled como true ou false.' });
  if (enabled && clientState !== 'ready') return res.status(409).json({ error: 'O WhatsApp ainda não está conectado.' });
  data.enabled = enabled;
  saveData();
  res.json({ ok: true, enabled: data.enabled });
});

function initClient() {
  initInProgress = true;
  if (client) {
    try { client.destroy(); } catch (_) {}
    client = null;
  }
  client = new Client({
    authStrategy: new LocalAuth({ clientId: 'medeiros-divulgacao', dataPath: AUTH_DIR }),
    puppeteer: {
      executablePath: CHROMIUM_PATH,
      headless: true,
      timeout: 120000,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--no-zygote']
    },
    takeoverOnConflict: false,
    qrMaxRetries: 5,
    authTimeoutMs: 120000
  });
  client.on('qr', qr => { latestQR = qr; clientState = 'qr'; lastError = null; console.log('QR Code gerado; aguardando leitura.'); });
  client.on('authenticated', () => { latestQR = null; clientState = 'authenticated'; console.log('WhatsApp autenticado.'); });
  client.on('ready', () => { latestQR = null; clientState = 'ready'; lastError = null; initInProgress = false; console.log('WhatsApp conectado e pronto.'); });
  client.on('loading_screen', (percent, message) => console.log(`WhatsApp carregando: ${percent}% ${message || ''}`));
  client.on('change_state', state => console.log('Estado WhatsApp:', state));
  client.on('auth_failure', message => { clientState = 'error'; lastError = String(message); initInProgress = false; console.error('Falha de autenticação WhatsApp:', message); });
  client.on('disconnected', reason => { clientState = 'disconnected'; lastError = String(reason); initInProgress = false; data.enabled = false; saveData(); console.error('WhatsApp desconectado:', reason); });
  client.initialize().catch(error => {
    clientState = 'error';
    lastError = error && error.message ? error.message : String(error);
    initInProgress = false;
    data.enabled = false;
    saveData();
    console.error('Erro ao inicializar WhatsApp:', error);
  });
}

async function runScheduler() {
  if (tickBusy || !data.enabled || clientState !== 'ready' || !client) return;
  tickBusy = true;
  try {
    const now = localTimeParts();
    const today = todayKey();
    if (!data.sent[today]) data.sent[today] = 0;
    for (const schedule of data.schedules) {
      if (!data.enabled || clientState !== 'ready') break;
      if (!schedule.active || schedule.time !== now.time || !schedule.days.includes(now.day)) continue;
      for (const groupId of schedule.groupIds) {
        if (!data.enabled || clientState !== 'ready') break;
        if (Number(data.sent[today] || 0) >= MAX_MESSAGES_PER_DAY) {
          console.warn('Limite diário atingido; demais envios foram pausados.');
          data.enabled = false;
          saveData();
          break;
        }
        const already = data.sent[`${today}:${schedule.id}:${groupId}`];
        if (already) continue;
        try {
          await client.sendMessage(groupId, schedule.message);
          data.sent[`${today}:${schedule.id}:${groupId}`] = true;
          data.sent[today] = Number(data.sent[today] || 0) + 1;
          saveData();
          console.log(`Mensagem enviada para grupo ${groupId}; total hoje: ${data.sent[today]}`);
          await new Promise(resolve => setTimeout(resolve, 5000));
        } catch (error) {
          console.error(`Falha ao enviar para ${groupId}:`, error.message);
        }
      }
    }
    // Mantém apenas os registros recentes para o arquivo não crescer indefinidamente.
    const keys = Object.keys(data.sent);
    if (keys.length > 500) {
      const keep = {};
      for (const key of keys.slice(-300)) keep[key] = data.sent[key];
      data.sent = keep;
      saveData();
    }
  } catch (error) { console.error('Erro no agendador:', error); }
  finally { tickBusy = false; }
}

cron.schedule('* * * * *', runScheduler, { timezone: TZ });

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Robô Medeiros agendador em 0.0.0.0:${PORT}`);
  console.log(`Fuso horário: ${TZ}; limite diário: ${MAX_MESSAGES_PER_DAY}`);
  if (ADMIN_PASSWORD) initClient();
});

const PANEL_HTML = `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Robô Medeiros</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#0c0c0f;color:#f5f5f5;font:15px Arial,sans-serif}.wrap{max-width:850px;margin:auto;padding:20px}.card{background:#17171d;border:1px solid #30303a;border-radius:14px;padding:18px;margin:14px 0}h1{font-size:24px;margin:4px 0 8px;color:#e8c879}h2{font-size:18px;margin:0 0 14px}p,.muted{color:#b8b8c2}.row{display:flex;gap:10px;flex-wrap:wrap}input,textarea,select{width:100%;padding:12px;border:1px solid #454552;border-radius:9px;background:#101015;color:#fff;margin:6px 0 12px}textarea{min-height:100px}button{border:0;border-radius:9px;background:#d4ad55;color:#17120a;padding:12px 16px;font-weight:bold;margin:4px 4px 4px 0;cursor:pointer}button.secondary{background:#33333e;color:white}button.danger{background:#8d3434;color:white}.status{padding:10px;background:#101015;border-radius:9px;margin:10px 0;overflow-wrap:anywhere}.group{display:block;padding:8px;border-bottom:1px solid #30303a}.days label{display:inline-block;margin:6px 10px 6px 0}.item{padding:12px 0;border-top:1px solid #333}.item small{color:#aaa}.hidden{display:none}#qr{max-width:300px;width:100%;background:white;padding:8px;border-radius:8px}button:disabled{opacity:.5}
</style></head><body><main class="wrap"><h1>MEDEIROS DIGITAL</h1><p class="muted">Painel de agendamento de divulgações</p>
<section class="card"><h2>Acesso administrativo</h2><label for="password">Senha de administrador</label><input id="password" type="password" autocomplete="current-password" placeholder="Digite sua ADMIN_PASSWORD"><div class="row"><button id="loginBtn" onclick="login()">Entrar / atualizar status</button><button class="secondary" onclick="connect()">Conectar WhatsApp</button></div><div id="status" class="status">Aguardando acesso.</div><div id="qrbox" class="hidden"><p>Leia este QR Code no WhatsApp: Aparelhos conectados → Conectar aparelho.</p><img id="qr" alt="QR Code do WhatsApp"></div></section>
<div id="apparea" class="hidden">
<section class="card"><h2>Grupos autorizados</h2><p class="muted">Selecione somente grupos que autorizaram receber suas divulgações.</p><button onclick="loadGroups()">Carregar grupos</button><div id="groups" class="status">Nenhum grupo carregado.</div></section>
<section class="card"><h2>Novo agendamento</h2><label for="message">Mensagem</label><textarea id="message" maxlength="4000" placeholder="Digite a divulgação..."></textarea><label for="time">Horário</label><input id="time" type="time" value="12:00"><div class="days" id="days"></div><button onclick="saveSchedule()">Salvar agendamento</button></section>
<section class="card"><h2>Automação</h2><div class="row"><button onclick="setEnabled(true)">Ativar envios</button><button class="danger" onclick="setEnabled(false)">Pausar envios</button></div><p class="muted">Ative somente depois de conferir mensagem, grupos, horário e autorização. O limite diário configurado é exibido no status.</p></section>
<section class="card"><h2>Agendamentos salvos</h2><div id="schedules">Nenhum agendamento.</div></section></div>
</main><script>
let token='';let groups=[];const $=id=>document.getElementById(id);
const dayNames=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
$('days').innerHTML=dayNames.map((name,i)=>'<label><input style="width:auto;margin:0" type="checkbox" value="'+i+'" '+(i>0&&i<6?'checked':'')+'> '+name+'</label>').join('');
function msg(text){$('status').textContent=text}
function headers(){return {'Content-Type':'application/json','Authorization':'Bearer '+token}}
async function api(url,options={}){const response=await fetch(url,{...options,headers:{...headers(),...(options.headers||{})}});let result={};try{result=await response.json()}catch(_){}if(!response.ok)throw new Error(result.error||'Erro HTTP '+response.status);return result}
async function login(){token=$('password').value.trim();if(!token){msg('Digite a senha administrativa.');return}try{const s=await api('/api/status');$('apparea').classList.remove('hidden');showStatus(s);msg('Acesso administrativo confirmado.');await refreshQR()}catch(e){token='';msg(e.message)}}
async function connect(){if(!token){await login();if(!token)return}try{const r=await api('/api/connect',{method:'POST',body:'{}'});msg(r.message||'Conexão solicitada.');setTimeout(refreshQR,2500);setTimeout(refreshQR,7000)}catch(e){msg(e.message)}}
async function refreshQR(){try{const r=await api('/api/qr');if(r.qr){$('qr').src=r.qr;$('qrbox').classList.remove('hidden')}else{$('qrbox').classList.add('hidden')}if(r.lastError)msg('WhatsApp: '+r.state+' — '+r.lastError);else msg('WhatsApp: '+r.state)}catch(e){msg(e.message)}}
function showStatus(s){msg('WhatsApp: '+s.state+' | Automação: '+(s.enabled?'ATIVA':'PAUSADA')+' | Envios hoje: '+s.sentToday+'/'+s.maxPerDay+(s.lastError?' | Erro: '+s.lastError:''));renderSchedules(s.schedules||[])}
async function loadStatus(){const s=await api('/api/status');showStatus(s)}
async function loadGroups(){try{const r=await api('/api/groups');groups=r.groups||[];$('groups').innerHTML=groups.length?groups.map(g=>'<label class="group"><input style="width:auto" type="checkbox" value="'+escapeHtml(g.id)+'"> '+escapeHtml(g.name)+'</label>').join(''):'Nenhum grupo encontrado.'}catch(e){msg(e.message)}}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function saveSchedule(){try{const groupIds=[...$('groups').querySelectorAll('input[type=checkbox]:checked')].map(x=>x.value);const days=[...$('days').querySelectorAll('input:checked')].map(x=>Number(x.value));const payload={message:$('message').value,groupIds,time:$('time').value,days,active:true};await api('/api/schedules',{method:'POST',body:JSON.stringify(payload)});$('message').value='';await loadStatus();msg('Agendamento salvo. A automação continua pausada até você ativá-la.')}catch(e){msg(e.message)}}
function renderSchedules(items){$('schedules').innerHTML=items.length?items.map(s=>'<div class="item"><b>'+escapeHtml(s.time)+'</b> — '+escapeHtml(s.message.slice(0,100))+'<br><small>'+escapeHtml(s.groupIds.length+' grupo(s) · dias '+s.days.map(d=>dayNames[d]).join(', ')+' · '+(s.active?'ativo':'pausado'))+'</small><br><button class="secondary" onclick="toggleSchedule(\''+s.id+'\','+(!s.active)+')">'+(s.active?'Pausar':'Ativar')+'</button><button class="danger" onclick="deleteSchedule(\''+s.id+'\')">Excluir</button></div>').join(''):'Nenhum agendamento.'}
async function toggleSchedule(id,active){try{await api('/api/schedules/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({active})});await loadStatus()}catch(e){msg(e.message)}}
async function deleteSchedule(id){if(!confirm('Excluir este agendamento?'))return;try{await api('/api/schedules/'+encodeURIComponent(id),{method:'DELETE'});await loadStatus()}catch(e){msg(e.message)}}
async function setEnabled(enabled){try{await api('/api/enabled',{method:'POST',body:JSON.stringify({enabled})});await loadStatus()}catch(e){msg(e.message)}}
window.addEventListener('error',e=>msg('Erro no painel: '+e.message));
</script></body></html>`;
